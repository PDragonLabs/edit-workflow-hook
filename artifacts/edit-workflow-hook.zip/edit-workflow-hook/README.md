# AIVIDMUSLLM — Edit Workflow Hook

PDragonLabs short: alchemy × tech. 9:16 HyperFrames composition.

Talking-head plate is your HeyGen lip-sync export (`assets/talking.mp4`, 36.67s).

## What’s in here

| File | Role |
|---|---|
| `index.html` | 1080×1920 composition — a-roll, Ken Burns wrap, kinetic captions, VO |
| `assets/talking.mp4` | 9:16 talking-head plate (H.264 + AAC) |
| `assets/host.jpg` | Still fallback |
| `assets/vo.mp3` | Earlier 13s hook VO (kept) |

Brand lockup: **PDRAGONLABS** · *Solve et coagula · As above, so below*

## Preview / render

Needs Node 22+ and FFmpeg.

```bash
npm run dev      # Studio preview
npm run check    # lint + layout + motion + contrast
npm run render   # write an MP4
```

HeyGen watermarks are baked into the current plate. Re-export without them and drop the file on `assets/talking.mp4`.
